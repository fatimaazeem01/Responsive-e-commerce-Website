# Final Project
A responsive e-commerce platform using HTML, CSS, JavaScript, Tailwind CSS, React.js, Redux Toolkit, Formik, and Yup. 
The platform should include a landing page, product listings, detailed product pages, a shopping cart, a multi-step checkout process,
an order history page, and an admin panel for managing products and user accounts.

